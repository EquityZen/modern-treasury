class ModernTreasuryException(Exception):
    pass
